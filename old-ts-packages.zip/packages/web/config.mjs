export default {
  url: "https://opencode.ai",
  socialCard: "https://social-cards.sst.dev",
  github: "https://github.com/sst/opencode",
  headerLinks: [
    { name: "Home", url: "/" },
    { name: "Docs", url: "/docs/" },
  ],
}
