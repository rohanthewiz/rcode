export const foo: string = "42"
export const bar: number = 123

export function dummyFunction(): void {
  console.log("This is a dummy function")
}

export function randomHelper(): boolean {
  return Math.random() > 0.5
}
